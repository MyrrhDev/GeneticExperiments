var searchData=
[
  ['primer_5fnode',['primer_node',['../class_arbre.html#a62818cdde6c1912a7c9a15db3b93d297',1,'Arbre']]],
  ['punto_5fde_5fcorte',['punto_de_corte',['../class_cromosomas.html#a6d75420146a2e5a7e9c61b3e3e8f918a',1,'Cromosomas']]]
];
