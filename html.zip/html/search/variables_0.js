var searchData=
[
  ['croms',['croms',['../class_individuo.html#aea843f29e05a89fad0eff12c7dadc285',1,'Individuo']]]
];
