var searchData=
[
  ['tiene_5fpadres',['tiene_padres',['../class_familias.html#ada07689f8d59c8ae0f107f27de1cbee4',1,'Familias']]]
];
