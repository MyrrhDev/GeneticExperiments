var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;program.cc'],['../testfamily_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;testfamily.cc']]],
  ['mensaje',['mensaje',['../class_p_r_o2_excepcio.html#aa82c5df8e191f4b6134cd85d270a9e87',1,'PRO2Excepcio']]],
  ['mismos_5fpadres',['mismos_padres',['../class_familias.html#aecef189fae2a02cf7db70e8582cea108',1,'Familias']]]
];
