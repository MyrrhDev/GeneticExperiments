var searchData=
[
  ['two',['two',['../struct_cromosomas_1_1_crom.html#a2fcbc5a412d2d1edc1a78d098e94393e',1,'Cromosomas::Crom']]]
];
