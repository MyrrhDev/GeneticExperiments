var searchData=
[
  ['cromosoma',['Cromosoma',['../class_cromosomas.html#a266e4108b63c2b535ddca35c3e2d7aea',1,'Cromosomas']]]
];
