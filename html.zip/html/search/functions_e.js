var searchData=
[
  ['what',['what',['../class_p_r_o2_excepcio.html#a2198874fa655545d756954044752c829',1,'PRO2Excepcio']]]
];
