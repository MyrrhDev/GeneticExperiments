var searchData=
[
  ['genotipo',['genotipo',['../class_cromosomas.html#a2450a613dc87bcd8fd6879f4bf7c7f1b',1,'Cromosomas']]],
  ['gensexs',['gensexs',['../class_cromosomas.html#a1b47744a07d136a34f9623c78fba26d1',1,'Cromosomas']]]
];
