var searchData=
[
  ['testfamily_2ecc',['testfamily.cc',['../testfamily_8cc.html',1,'']]],
  ['tiene_5fpadres',['tiene_padres',['../class_familias.html#ada07689f8d59c8ae0f107f27de1cbee4',1,'Familias']]],
  ['two',['two',['../struct_cromosomas_1_1_crom.html#a2fcbc5a412d2d1edc1a78d098e94393e',1,'Cromosomas::Crom']]]
];
