var searchData=
[
  ['definir_5fespecie',['definir_especie',['../class_cromosomas.html#adc503d28502b00f608e775bb2c99c268',1,'Cromosomas']]]
];
