var searchData=
[
  ['lx',['lx',['../class_cromosomas.html#a3b41f155658caa9785773a65df485a28',1,'Cromosomas']]],
  ['ly',['ly',['../class_cromosomas.html#a4715f7b7a3fa61c61104e01d3fee986c',1,'Cromosomas']]]
];
