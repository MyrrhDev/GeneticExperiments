var searchData=
[
  ['one',['one',['../struct_cromosomas_1_1_crom.html#a1b7cb0788d907b0e864889db9cd715d7',1,'Cromosomas::Crom']]]
];
