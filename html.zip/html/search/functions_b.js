var searchData=
[
  ['recoge_5fsex',['recoge_sex',['../class_individuo.html#ad194d295cbe37cff9d276985e9cdde98',1,'Individuo']]],
  ['reproducir_5findividuos',['reproducir_individuos',['../class_especie.html#a6dbfedb08e923172a004468ae2795619',1,'Especie']]]
];
