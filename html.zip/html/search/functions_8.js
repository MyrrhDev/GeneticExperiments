var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;program.cc'],['../testfamily_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main():&#160;testfamily.cc']]],
  ['mismos_5fpadres',['mismos_padres',['../class_familias.html#aecef189fae2a02cf7db70e8582cea108',1,'Familias']]]
];
